/* - - - - - - - - - - - - - - - - - -
	accordion
	- - - - - - - - - - - - - - - - - - */
	//Global Flags
	var flag  		= false, 
		closed 		= false,
		navHeight	= 63,
		scrolled 	= false;

	$('body').on('click','.panel-heading h4 a',function() {
		var $target = $(this).parents('.panel.panel-default'),
			$first 	= $(this).parents('div[id*="accordion"]').find('.panel-heading h4 a').first(),
			nav 	= $('#header-full'),
			$active = $('.panel-default.active .panel-heading a'),
			$tabs	= $('.panel-heading h4 > a'),
			$panels = $('div.panel.panel-default > div[role="tabpanel"]'),
			str 	= $.trim($(this).text());

		if (scrolled === true) {
			navHeight = 63;
			console.log('navHeight after page load: '+ navHeight);
		}

		if ($active.is($(this)) && !closed) {
			closed = true;
		}else {
			closed = false;
		}

		$('.panel').removeClass('active');
		
		//Setting up Aria values.
		$tabs.attr({
			'aria-selected': false,
			'aria-expanded': false
		});
		$panels.attr('aria-hidden', true);
		
		if (closed) {
			$(this).attr({
				'aria-selected': true,
				'aria-expanded': false
			});
			$(this).parents('.panel-heading').next('.collapse').attr('aria-hidden',true);
		}else {
			$(this).attr({
				'aria-selected': true,
				'aria-expanded': true
			});
			$(this).parents('.panel-heading').next('.collapse').attr('aria-hidden',false);
		}

		$target.toggleClass('active',function () {
			if (!$(this).is('first') && flag ) {
				flag = false;
				$('html,body').animate({
          			scrollTop: $first.parents('.panel.panel-default').offset().top - navHeight
        		}, 900);
			}else if (!$(this).is($first) && closed) {
				$('html,body').animate({
          			scrollTop: $first.parents('.panel.panel-default').offset().top - navHeight
        		}, 900);
			}else {
				$('html,body').animate({
          			scrollTop: $target.offset().top - navHeight
        		}, 900);
			}

		});
	        if ($(this).parent().parent().parent().parent().attr("id") == "accordion1" ) {
	            $("#accordion2 panel").removeClass("active");
	            $("#accordion2 div[id^='faq']").removeClass("in");
	        } else {
	            $("#accordion1 panel").removeClass("active");
	            $("#accordion1 div[id^='faq']").removeClass("in");
	        }

	        try {
	        	tracking(str);
	        }catch (e) {
	        	console.log('There was a tracking error' + e)
	        }
	 
	}).on('keydown','.panel-heading h4 a',function (event) {
		var $accordion 	= $(this).parents('div[id*="accordion"]'),
			$first 		= $accordion.find('.panel-heading h4 a').first(),
			$last 		= $accordion.find('.panel-heading h4 a').last();
		
		//up and left arrow goes back to the previous item of the accordion.
		if ( event.keyCode === 37 || event.keyCode === 38 && !event.ctrlKey ) {
			//Check if we are in the first tab if so move the focus to the last one.
			if ($(this).is($first)) {
				$last.focus();
			}else {
				$(this).parents('.panel-default').prev().find('.panel-heading h4 a').focus()
			}
		//down and right arrow goes back to the previous item of the accordion.
		}else if ( event.keyCode === 39 || event.keyCode === 40 && !event.ctrlKey ) {
			//Check if we are in the last tab, if so move the focus to the first one.
			if ($(this).is($last)) {
				$first.focus();
			}else {
				$(this).parents('.panel-default').next().find('.panel-heading h4 a').focus();
			}
		}
 	});
	$("body").on('click','.faqs-group li > a',function(){
		var str 	= $.trim($(this).text()),
			$tabs	= $('.faqs-group li > a'),
			$panels	= $('.faqs-group li > div[role="tabpanel"]');

			$tabs.attr({
				'aria-expanded': false,
				'aria-selected': false,
			});
			$panels.attr({
				'aria-hidden': true,
			});

			if (!$(this).hasClass('expanded')) {
				$(this).attr({
					'aria-expanded': true,
					'aria-selected': true,
				});
				$(this).parent('li').children('.collapse').attr({
					'aria-hidden': false
				});
			}else {
				$(this).attr({
					'aria-expanded': false,
					'aria-selected': false,
				});
				$(this).parent('li').children('.collapse').attr({
					'aria-hidden': true
				});
			}

		$(this).toggleClass("expanded",function () {
			if ($(this).hasClass('expanded')) {
				$('html,body').animate({
		          scrollTop: $(this).parent().offset().top - navHeight
		        }, 900);
			}else {
				$('html,body').animate({
		          scrollTop: $(this).parents('.panel.panel-default').offset().top - navHeight
		        }, 900);
		        flag = true;
			}
		});
		try {
			tracking(str);
		}catch (e) {
			console.log('There was a Tracking error: ' + e);
		}
	}).on('keydown','.faqs-group li > a',function (event){
		var $accordion = $(this).parents('ul'),
			$first 	   = $accordion.find('li:first-child > a'),
			$last 	   = $accordion.find('li:last-child > a');
		if ( event.keyCode === 37 || event.keyCode === 38 && !event.ctrlKey ) {
			if ( $(this).is($first)) {
				$last.focus();
			}else {
				$(this).parent('li').prev().children('a').focus();
			}
		}else if (event.keyCode === 39 || event.keyCode === 40 && !event.ctrlKey) {
			if ( $(this).is($last)) {
				$first.focus();
			}else {
				$(this).parent('li').next().children('a').focus();
			}
		}
	});

	$.getUrlVar = function(key){
	var param = new RegExp(key + "=([^&]*)","i").exec(window.location.search);
	return param && unescape(param[1]) || "";
	}

	$(window).load(function () {
		var tabIndex = $.getUrlVar('tab'), subTabIndex = $.getUrlVar('subTab');//Aqui va el parametro para setear el tab.

		if ( (tabIndex && tabIndex !== '0') && (subTabIndex && subTabIndex !== '0') ) {
		   tabIndex    -= 1;
		   subTabIndex -= 1;
		   $('html,body').animate({
	 			scrollTop: $('.panel-default').eq(tabIndex).parent('[id*="accordion"]').offset().top - navHeight
		   }, 900, function () {
		   		$('.panel-default').eq(tabIndex).find('.panel-title a').click()
		   		.parents('.panel-heading').next().find('.panel-body ul li').eq(subTabIndex).find('a').click().addClass('expanded');
		   });
		}else if (tabIndex && tabIndex !== '0') {
			tabIndex -= 1;
			if ($('.panel-default').eq(tabIndex).hasClass('active')) {
				$('html,body').animate({
	      			scrollTop: $('.panel-default').eq(tabIndex).parent('[id*="accordion"]').offset().top - navHeight
	    		}, 900);

			}else {
				$('html,body').animate({
			 		scrollTop: $('.panel-default').eq(tabIndex).parent('[id*="accordion"]').offset().top - navHeight
				  }, 900, function () {
				   	$('.panel-default').eq(tabIndex).find('.panel-title a').click()
				});
				
			}
		}
	});
